export const searchPagePaginationLength = 20;
