export const NavData = [
  {
    name: "Bosh Sahifa",
    url: "/",
  },
  {
    name: "Ish o'rinlari",
    url: "/search",
  },
  {
    name: "Monomarkazlar",
    url: "/edu",
  },
];
